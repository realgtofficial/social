import type { Config } from "@netlify/functions";
import { adminPassword, makeToken, safeEqual } from "../lib/auth.mts";

const reply = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });

export default async (req: Request) => {
  if (req.method !== "POST") return reply({ error: "Use POST." }, 405);

  const password = adminPassword();
  if (!password) {
    return reply({ error: "The admin password is not set up yet. Add ADMIN_PASSWORD in Netlify (at least 8 characters) and deploy again." }, 503);
  }

  let given = "";
  try {
    const body = await req.json();
    if (body && typeof body.password === "string") given = body.password;
  } catch {
    // Not valid JSON: treated as a wrong password below.
  }

  if (given.length > 200 || !(await safeEqual(given, password))) {
    await new Promise((r) => setTimeout(r, 1000)); // slows down guessing
    return reply({ error: "Wrong password." }, 401);
  }

  const { token, exp } = await makeToken(password);
  return reply({ token, exp });
};

export const config: Config = {
  path: "/api/login",
  rateLimit: { action: "rate_limit", aggregateBy: ["ip", "domain"], windowLimit: 10, windowSize: 60 },
};
