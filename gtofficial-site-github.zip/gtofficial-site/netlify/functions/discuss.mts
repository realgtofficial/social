import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { adminPassword, checkToken } from "../lib/auth.mts";

const reply = (data: unknown, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
});
const clean = (v: unknown, max: number) => typeof v === "string" ? v.trim().slice(0, max) : "";
const validId = (v: unknown) => typeof v === "string" && /^[a-zA-Z0-9_-]{8,80}$/.test(v);
const validVisitor = (v: unknown) => typeof v === "string" && /^[a-zA-Z0-9_-]{8,80}$/.test(v);
const stores = () => getStore("gtofficial-discussion");

export default async (req: Request) => {
  const url = new URL(req.url), action = url.searchParams.get("action") || "";
  let store;
  try { store = stores(); }
  catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    return reply({ error: `Discussion storage initialization failed: ${detail}` }, 503);
  }
  if (req.method === "GET" && action === "moderate") {
    const password = adminPassword();
    if (!password || !(await checkToken(req, password))) return reply({ error: "Admin login required." }, 401);
    const listed = await store.list({ prefix: "posts/" });
    const posts = await Promise.all(listed.blobs.map(async (b) => store.get(b.key, { type: "json" })));
    const cleanPosts = posts.filter((p: any) => p && typeof p === "object").sort((a: any, b: any) => Number(b.createdAt || 0) - Number(a.createdAt || 0));
    const summary = await Promise.all(cleanPosts.map(async (p: any) => {
      const reactions = await store.get(`reactions/${p.id}`, { type: "json" }) || {};
      const comments = await store.get(`comments/${p.id}`, { type: "json" }) || [];
      const vals = Object.values(reactions) as string[];
      return { id: p.id, name: p.name || "Anonymous", anonymous: Boolean(p.anonymous), text: p.text, createdAt: p.createdAt, likes: vals.filter(v => v === "like").length, dislikes: vals.filter(v => v === "dislike").length, commentCount: Array.isArray(comments) ? comments.length : 0 };
    }));
    return reply({ posts: summary });
  }
  if (req.method === "GET" && !action) {
    let listed;
    try { listed = await store.list({ prefix: "posts/" }); }
    catch (err) { return reply({ error: `Community posts could not be read: ${err instanceof Error ? err.message : String(err)}` }, 503); }
    const posts = await Promise.all(listed.blobs.slice(0, 500).map(async (b) => store.get(b.key, { type: "json" })));
    const cleanPosts = posts.filter((p: any) => p && typeof p === "object").sort((a: any, b: any) => Number(b.createdAt || 0) - Number(a.createdAt || 0));
    const visitorId = url.searchParams.get("visitorId");
    const summary = await Promise.all(cleanPosts.map(async (p: any) => {
      const reactions = await store.get(`reactions/${p.id}`, { type: "json" }) || {};
      const comments = await store.get(`comments/${p.id}`, { type: "json" }) || [];
      const vals = Object.values(reactions) as string[];
      return { ...p, visitorId: undefined, myReaction: validVisitor(visitorId) ? reactions[visitorId!] || "" : "", likes: vals.filter(v => v === "like").length, dislikes: vals.filter(v => v === "dislike").length, commentCount: Array.isArray(comments) ? comments.length : 0 };
    }));
    return reply({ posts: summary });
  }
  if (req.method === "GET" && action === "comments") {
    const postId = url.searchParams.get("postId");
    if (!validId(postId)) return reply({ error: "Invalid post." }, 400);
    const comments = await store.get(`comments/${postId}`, { type: "json" }) || [];
    return reply({ comments: Array.isArray(comments) ? comments.slice(-200) : [] });
  }
  if (req.method !== "POST") return reply({ error: "Method not allowed." }, 405);
  // Reject cross-origin write requests where an Origin header is present.
  const origin = req.headers.get("origin");
  // Netlify may expose an internal function URL in req.url; compare Origin to the
  // public host forwarded by the platform rather than req.url's host.
  if (origin) {
    try {
      const originHost = new URL(origin).host.toLowerCase();
      const publicHost = (req.headers.get("x-forwarded-host") || req.headers.get("host") || url.host).split(",")[0].trim().toLowerCase();
      if (originHost !== publicHost) return reply({ error: "Cross-origin request blocked." }, 403);
    } catch { return reply({ error: "Invalid origin." }, 403); }
  }
  let body: any;
  try { body = await req.json(); } catch { return reply({ error: "Invalid JSON." }, 400); }
  if (action === "create") {
    const text = clean(body.text, 2000), name = clean(body.name, 30), visitorId = body.visitorId, anonymous = body.anonymous === true;
    if (!text) return reply({ error: "Write something before posting." }, 400);
    if (!anonymous && !name) return reply({ error: "Display name is required unless you post anonymously." }, 400);
    if (!validVisitor(visitorId)) return reply({ error: "Refresh the page and try again." }, 400);
    const id = crypto.randomUUID();
    const post = { id, name: anonymous ? "Anonymous" : name, anonymous, text, createdAt: Date.now(), visitorId };
    try {
      await store.setJSON(`posts/${id}`, post);
      return reply({ post }, 201);
    } catch (err) {
      const detail = err instanceof Error ? err.message : String(err);
      return reply({ error: `Post save failed in storage: ${detail}` }, 503);
    }
  }
  if (action === "comment") {
    const postId = body.postId, text = clean(body.text, 500), name = clean(body.name, 30), visitorId = body.visitorId;
    if (!validId(postId) || !validVisitor(visitorId) || !text) return reply({ error: "Post, name and comment are required." }, 400);
    const post = await store.get(`posts/${postId}`, { type: "json" }); if (!post) return reply({ error: "Post not found." }, 404);
    const comments = await store.get(`comments/${postId}`, { type: "json" }) || [];
    if (!Array.isArray(comments) || comments.length >= 500) return reply({ error: "This post has reached its comment limit." }, 409);
    const comment = { id: crypto.randomUUID(), name: name || "Anonymous", anonymous: !name, text, createdAt: Date.now() };
    comments.push(comment); await store.setJSON(`comments/${postId}`, comments);
    return reply({ comment }, 201);
  }
  if (action === "react") {
    const postId = body.postId, visitorId = body.visitorId, reaction = body.reaction;
    if (!validId(postId) || !validVisitor(visitorId) || !["like", "dislike", "none"].includes(reaction)) return reply({ error: "Invalid reaction." }, 400);
    const post = await store.get(`posts/${postId}`, { type: "json" }); if (!post) return reply({ error: "Post not found." }, 404);
    const reactions = await store.get(`reactions/${postId}`, { type: "json" }) || {};
    if (reaction === "none") delete reactions[visitorId]; else reactions[visitorId] = reaction;
    await store.setJSON(`reactions/${postId}`, reactions);
    const vals = Object.values(reactions) as string[];
    return reply({ likes: vals.filter(v => v === "like").length, dislikes: vals.filter(v => v === "dislike").length, mine: reactions[visitorId] || "" });
  }
  if (action === "delete") {
    const password = adminPassword();
    if (!password || !(await checkToken(req, password))) return reply({ error: "Admin login required." }, 401);
    const postId = body.postId;
    if (!validId(postId)) return reply({ error: "Invalid post ID." }, 400);
    const post = await store.get(`posts/${postId}`, { type: "json" });
    if (!post) return reply({ error: "Post not found." }, 404);
    await Promise.all([store.delete(`posts/${postId}`), store.delete(`comments/${postId}`), store.delete(`reactions/${postId}`)]);
    return reply({ ok: true });
  }
  return reply({ error: "Unknown action." }, 400);
};

export const config: Config = {
  path: "/api/discuss",
  rateLimit: { action: "rate_limit", aggregateBy: ["ip", "domain"], windowLimit: 30, windowSize: 60 },
};
