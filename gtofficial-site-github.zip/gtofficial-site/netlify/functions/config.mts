import type { Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";
import { adminPassword, checkToken } from "../lib/auth.mts";
import { sanitizeConfig, ValidationError } from "../lib/sanitize.mts";
import { DEFAULTS } from "../lib/defaults.mts";

const reply = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });

// GET /api/config   public: the values the website shows
// GET /api/session  needs login: tells the admin page its login is still valid
// PUT /api/config   needs login: saves new values
export default async (req: Request) => {
  const path = new URL(req.url).pathname.replace(/\/+$/, "");
  const store = getStore("gtofficial");

  if (path === "/api/config" && req.method === "GET") {
    const saved = await store.get("config", { type: "json", consistency: "strong" });
    return reply(saved ?? DEFAULTS);
  }

  if (req.method !== "GET" && req.method !== "PUT") return reply({ error: "Method not allowed." }, 405);

  const password = adminPassword();
  if (!password) return reply({ error: "The admin password is not set up yet." }, 503);
  if (!(await checkToken(req, password))) return reply({ error: "Please log in again." }, 401);

  if (path === "/api/session" && req.method === "GET") return reply({ ok: true });

  if (path === "/api/config" && req.method === "PUT") {
    const raw = await req.text();
    if (raw.length > 200_000) return reply({ error: "That is too much data to save." }, 413);
    let clean;
    try {
      clean = sanitizeConfig(JSON.parse(raw));
    } catch (err) {
      if (err instanceof ValidationError) return reply({ error: err.message }, 400);
      return reply({ error: "The data could not be read." }, 400);
    }
    await store.setJSON("config", clean);
    return reply(clean);
  }

  return reply({ error: "Not found." }, 404);
};

export const config: Config = { path: ["/api/config", "/api/session"] };
